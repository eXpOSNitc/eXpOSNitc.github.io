# nexsm

The NEXSM (NExt eXperimental String Machine) Simulator is used to simulate the NEXSM hardware
