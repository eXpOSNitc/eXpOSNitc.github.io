ExpL compiler for eXpOS

Usage
-----

 ./expl <path to ExpL program>